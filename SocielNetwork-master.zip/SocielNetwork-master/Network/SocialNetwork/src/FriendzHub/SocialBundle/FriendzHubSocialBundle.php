<?php

namespace FriendzHub\SocialBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class FriendzHubSocialBundle extends Bundle
{

}
