Team Size:5
Language-Symphony,MySQL
Contribution-Implementing the login section, register user section, update post and review in time line
section including UI and database implementations
For this project we used symphony framework and CSS, Bootstrap and JavaScript. This system is capable
of registering users in the network, login to the system, entering profile information, accessing the time line
which shows posts added by all the users. Users can post status updates on the time line so others can see
it. Security and session handling are also included in this system.
